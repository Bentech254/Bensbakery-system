# Online-Bakery-Shop-Management-System-Php
This system allows bakery owners to sell their products to customer online via a web interface. The user can order and then pay for the item.
