
<div class="brand clearfix">
	
		<span class="menu-btn btn-sm"><i class="fa fa-bars"></i></span>
		<ul class="ts-profile-nav">

			<li class="ts-account">
				<a href="#"><img src="img/ts-avatar.jpg" class="ts-avatar hidden-side" alt=""> Account <i class="fa fa-angle-down hidden-side"></i></a>
				<ul>
					<li><a href="change-password.php">Change Password</a></li>
					<li><a href="logout.php">Logout</a></li>
				</ul>
			</li>
		</ul>
		<a href="dashboard.php" style="font-size: 20px; float: left;"> Tutsy Delights | Admin Panel</a> 
	</div>
