	<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">

				<li class="ts-label">Main Menu</li>
				<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
<li><a href="chart.php"><i class="fa fa-dashboard"></i> Bar Chart</a></li>
<li><a href="#"><i class="fa fa-files-o"></i> Categories</a>
<ul>
<li><a href="create-brand.php">Create Category</a></li>
<li><a href="manage-brands.php">Manage Categories</a></li>
</ul>
</li>
<li><a href="#"><i class="fa fa-files-o"></i>Sub Categories</a>
<ul>
<li><a href="create-sub-category.php">Create SubCategory</a></li>
<li><a href="manage-sub-category.php">Manage SubCategories</a></li>
</ul>
</li>
<li><a href="#"><i class="fa fa-sitemap"></i> cake</a>
					<ul>
						<li><a href="add-cake.php">Add a Cake</a></li>
						<li><a href="manage-cake.php">Manage cake</a></li>
					</ul>
				</li>
				<li><a href="manage-Orderings.php"><i class="fa fa-users"></i> Manage Orders</a></li>

				<li><a href="testimonials.php"><i class="fa fa-table"></i> Manage Testimonials</a></li>
				<li><a href="manage-conactusquery.php"><i class="fa fa-desktop""></i> Manage Contact Us Query</a></li>
				<li><a href="reg-users.php"><i class="fa fa-users"></i> Registered Users</a></li>
			<li><a href="manage-pages.php"><i class="fa fa-files-o"></i> Manage Pages</a></li>
			<li><a href="update-contactinfo.php"><i class="fa fa-files-o"></i> Update Contact Info</a></li>

			<li><a href="manage-subscribers.php"><i class="fa fa-table"></i> Manage Subscribers</a></li>
			<li><a href="employee.php"><i class="fa fa-users"></i> Manage Employees</a></li>


			</ul>
		</nav>
